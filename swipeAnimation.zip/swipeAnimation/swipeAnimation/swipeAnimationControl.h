//
//  swipeAnimationControl.h
//  swipeAnimation
//
//  Created by Jithin on 13/05/17.
//  Copyright © 2017 Accel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DraggableView.h"

@interface swipeAnimationControl : UIView <DraggableViewDelegate>

-(void)cardSwipedLeft:(UIView *)card;
-(void)cardSwipedRight:(UIView *)card;
-(void)swipeRight;
-(void)swipeLeft;
-(void)cleanCards;

@property (retain,nonatomic)NSMutableArray* allCards;


@end
