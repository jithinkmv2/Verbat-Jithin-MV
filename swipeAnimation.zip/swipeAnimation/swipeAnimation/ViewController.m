//
//  ViewController.m
//  swipeAnimation
//
//  Created by Jithin on 13/05/17.
//  Copyright © 2017 Accel. All rights reserved.
//

#import "ViewController.h"
#import "swipeAnimationControl.h"

@interface ViewController ()
@property swipeAnimationControl *swipeAnimation;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    _swipeAnimation = [[swipeAnimationControl alloc]initWithFrame:self.view.frame];
    _swipeAnimation.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_swipeAnimation];
    [self.view bringSubviewToFront:_UxBtnswipeLeft];
    [self.view bringSubviewToFront:_UxBtnReload];
    [self.view bringSubviewToFront:_uxBtnSwipeRight];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.

}
-(IBAction)_UxBtnswipeLeft:(id)sender
{
    [_swipeAnimation swipeLeft];
}

-(IBAction)_UxBtnReload:(id)sender
{
    [_swipeAnimation cleanCards];
    _swipeAnimation = [[swipeAnimationControl alloc]initWithFrame:self.view.frame];
    _swipeAnimation.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_swipeAnimation];
    [self.view bringSubviewToFront:_UxBtnswipeLeft];
    [self.view bringSubviewToFront:_UxBtnReload];
    [self.view bringSubviewToFront:_uxBtnSwipeRight];
}
-(IBAction)_uxBtnSwipeRight:(id)sender
{
    [_swipeAnimation swipeRight];
}
@end
