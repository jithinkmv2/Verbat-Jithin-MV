//
//  swipeAnimationControl.m
//  swipeAnimation
//
//  Created by Jithin on 13/05/17.
//  Copyright © 2017 Accel. All rights reserved.
//

#import "swipeAnimationControl.h"

@implementation swipeAnimationControl{
    NSInteger cardsLoadedIndex;
    NSMutableArray *loadedCards;
    NSInteger cardCount;
}
static const int MAX_BUFFER_SIZE = 2;
static const float CARD_HEIGHT = 500;
static const float CARD_WIDTH = 320;


@synthesize allCards;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [super layoutSubviews];
        [self setupView];
        loadedCards = [[NSMutableArray alloc] init];
         cardCount = 3;
        allCards = [[NSMutableArray alloc] init];
        cardsLoadedIndex = 0;
        [self loadCards];
    }
    return self;
}

-(void)setupView
{
    self.backgroundColor = [UIColor colorWithRed:.92 green:.93 blue:.95 alpha:1];

}

-(DraggableView *)createDraggableViewWithDataAtIndex:(NSInteger)index
{
    DraggableView *draggableView = [[DraggableView alloc]initWithFrame:CGRectMake((self.frame.size.width - CARD_WIDTH)/2, (self.frame.size.height - CARD_HEIGHT)/2, CARD_WIDTH, CARD_HEIGHT)];
    draggableView.delegate = self;
    return draggableView;
}

-(void)loadCards
{
    if(cardCount > 0) {
        NSInteger numLoadedCardsCap =((cardCount > MAX_BUFFER_SIZE)?MAX_BUFFER_SIZE:cardCount);

        for (int i = 0; i<cardCount; i++) {
            DraggableView* newCard = [self createDraggableViewWithDataAtIndex:i];
            newCard.layer.cornerRadius = 10;
            if (i==0)
            {
                newCard.backgroundColor = [UIColor colorWithRed:1.0 green:0.0 blue:0.0 alpha:0.5];
            }
            else if (i==1)
            {
                newCard.backgroundColor = [UIColor redColor];;            }
            else if (i==2)
            {
                newCard.backgroundColor = [UIColor whiteColor];
            }
            [allCards addObject:newCard];
            
            if (i<numLoadedCardsCap) {

                [loadedCards addObject:newCard];
            }
        }

        for (int i = 0; i<[loadedCards count]; i++) {
            if ((i>0) && (i<3)) {
                [self insertSubview:[loadedCards objectAtIndex:i] belowSubview:[loadedCards objectAtIndex:i-1]];
            } else {
                [self addSubview:[loadedCards objectAtIndex:i]];
            }
            cardsLoadedIndex++;
        }
    }
}

-(void)cardSwipedLeft:(UIView *)card;
{
    [loadedCards removeObjectAtIndex:0];
    
    if (cardsLoadedIndex < [allCards count]) {
        [loadedCards addObject:[allCards objectAtIndex:cardsLoadedIndex]];
        cardsLoadedIndex++;
        [self insertSubview:[loadedCards objectAtIndex:(MAX_BUFFER_SIZE-1)] belowSubview:[loadedCards objectAtIndex:(MAX_BUFFER_SIZE-2)]];
    }
}

-(void)cardSwipedRight:(UIView *)card
{
    [loadedCards removeObjectAtIndex:0];
    
    if (cardsLoadedIndex < [allCards count]) {
        [loadedCards addObject:[allCards objectAtIndex:cardsLoadedIndex]];
        cardsLoadedIndex++;
        [self insertSubview:[loadedCards objectAtIndex:(MAX_BUFFER_SIZE-1)] belowSubview:[loadedCards objectAtIndex:(MAX_BUFFER_SIZE-2)]];
    }

}

-(void)swipeRight
{
    DraggableView *dragView = [loadedCards firstObject];
    [UIView animateWithDuration:0.2 animations:^{
    }];
    [dragView rightClickAction];
}

-(void)swipeLeft
{
    DraggableView *dragView = [loadedCards firstObject];
    [UIView animateWithDuration:0.2 animations:^{
    }];
    [dragView leftClickAction];
}

-(void)cleanCards
{
   DraggableView *dragView = [loadedCards firstObject];
    [dragView remove];
}
@end
