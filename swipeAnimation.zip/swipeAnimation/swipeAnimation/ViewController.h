//
//  ViewController.h
//  swipeAnimation
//
//  Created by Jithin on 13/05/17.
//  Copyright © 2017 Accel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIButton *UxBtnswipeLeft;
@property (strong, nonatomic) IBOutlet UIButton *UxBtnReload;

@property (strong, nonatomic) IBOutlet UIButton *uxBtnSwipeRight;

@end

